# 21 Días Para Soltar · site do funil

Páginas: `index.html` (quiz de apego, é para onde o anúncio aponta) → `clase.html` (resultado + vídeo + oferta) → `gracias.html` (obrigado + chat) → `agendar.html` (agendar sesión).

## Antes de subir
Edite `assets/config.js`: os links da Hotmart (`checkout`, `sesionCheckout`), o preço da sessão, o Pixel e, se quiser, os preços exibidos.
Na Hotmart, configure:
- 21 Días Para Soltar (US$ 17) → página de obrigado: `https://SEU-DOMINIO/gracias.html`
- Order bump Audio de Emergencia (US$ 7)
- Sesión de valoración → página de obrigado: `https://SEU-DOMINIO/agendar.html`

## Netlify (recomendado)
1. app.netlify.com → Add new site → Deploy manually → arraste esta pasta (ou o .zip).
2. Site configuration → Forms → ative **Form detection** e faça o deploy de novo.
3. Forms → Form notifications → coloque seu e-mail. Os formulários são `soltar-quiz` (leads do quiz) e `soltar-agendamiento`.

## Vercel
1. vercel.com → Add New → Project → importe esta pasta (por GitHub) ou rode `npx vercel` dentro dela. Framework: **Other**, sem build.
2. **Atenção:** a Vercel não tem formulários embutidos. O funil funciona normalmente, mas os leads do quiz e os agendamentos **não ficam salvos**. Para guardar os leads na Vercel, seria preciso ligar um serviço externo (Formspree, planilha, Supabase).

## Testar
Para ver a oferta sem esperar o vídeo, adicione `?reveal=1` na URL de `clase.html`.
