/*
  CONFIGURAÇÃO — o único arquivo que você precisa editar antes de subir.
  - checkout / sesionCheckout: links da Hotmart.
  - vsl: "videos/soltar.mp4" (player próprio) ou o código do vturb.
  - revealSeconds: segundo do vídeo, assistido com som, em que a oferta aparece (início do pitch = 1:14).
  - Os parâmetros da URL (utm_*, fbclid, src, sck…) seguem automaticamente para o checkout.
*/
window.FUNIS = {
  pixelId: "",   // vazio de propósito: o Pixel 1088419540574942 está direto no <head> de cada página
  clarityId: "", // vazio de propósito: o Clarity yu310w5qa0 está direto no <head> de cada página

  soltar: {
    autora: "Aurora Reis",
    // Só escreva "Psicóloga · Colegiada nº ..." se ela for psicóloga registrada de verdade.
    registro: "Mentora de relaciones · creadora de 21 Días Para Soltar",
    checkout: "https://pay.hotmart.com/A105205689V?off=3mjdgjx9",
    precio: "US$ 17",        // front reduzido (antes US$ 27). Para teste A/B, troque aqui e no produto.
    bumpPrecio: "US$ 7",     // Audio de Emergencia: order bump configurado no checkout
    sesionCheckout: "https://pay.hotmart.com/TU-LINK-SESION",
    sesionPrecio: "[precio de la sesión]",
    vsl: "videos/soltar.mp4",
    revealSeconds: 74
  }
};
