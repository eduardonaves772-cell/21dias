/*
  Chat guiado dentro do funil (substitui o X1 no WhatsApp).
  Funil.chat(elemento, { nome, subtitulo, roteiro, inicio, estado })
  Cada passo do roteiro:
    { say: ["mensagem", ...],
      options: [{ label, next, set: {chave: valor} }],     // botões de resposta
      input: { name, placeholder, type, next },             // campo livre
      card: { title, price, note, items: [], button: { label, checkout }, secondary: { label, next } },
      track: "Lead" }                                       // evento do Pixel (opcional)
  Textos aceitam {chave} com o que a pessoa respondeu (ex.: {nome}).
*/
(function () {
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function fill(s, st) { return String(s).replace(/\{(\w+)\}/g, function (_, k) { return st[k] != null ? st[k] : ""; }); }
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function chat(root, opts) {
    var st = opts.estado || {};
    var steps = opts.roteiro;
    root.classList.add("chat");
    root.innerHTML =
      '<div class="chat-head"><div class="chat-av" aria-hidden="true">' + esc((opts.nome || "?").replace(/^\[/, "").charAt(0)) + '</div>' +
      '<div><b>' + esc(opts.nome || "") + '</b><small>' + esc(opts.subtitulo || "Assistente automática") + '</small></div></div>' +
      '<div class="chat-log" aria-live="polite"></div><div class="chat-actions"></div>';
    var log = root.querySelector(".chat-log");
    var actions = root.querySelector(".chat-actions");

    function scroll() { log.scrollTop = log.scrollHeight; }
    function bubble(html, who) {
      var b = document.createElement("div");
      b.className = "bub " + (who || "bot");
      b.innerHTML = html;
      log.appendChild(b); scroll();
      return b;
    }
    function typing(ms) {
      return new Promise(function (res) {
        if (reduce) { res(); return; }
        var t = bubble('<span class="dots"><i></i><i></i><i></i></span>', "bot typing");
        setTimeout(function () { t.remove(); res(); }, ms);
      });
    }
    function sayAll(list) {
      var p = Promise.resolve();
      (list || []).forEach(function (m) {
        var text = fill(m, st);
        p = p.then(function () { return typing(Math.min(1800, 500 + text.length * 14)); })
             .then(function () { bubble(esc(text).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\n/g, "<br>")); });
      });
      return p;
    }
    function go(id) {
      var s = steps[id];
      if (!s) return;
      actions.innerHTML = "";
      if (s.track && window.Funil) window.Funil.track(s.track);
      sayAll(s.say).then(function () {
        if (s.card) renderCard(s.card);
        if (s.options) {
          s.options.forEach(function (o) {
            var b = document.createElement("button");
            b.type = "button"; b.className = "chat-opt"; b.textContent = fill(o.label, st);
            b.addEventListener("click", function () {
              if (o.set) Object.keys(o.set).forEach(function (k) { st[k] = o.set[k]; });
              bubble(esc(fill(o.label, st)), "me");
              actions.innerHTML = "";
              if (opts.onAnswer) opts.onAnswer(id, o, st);
              go(o.next);
            });
            actions.appendChild(b);
          });
        }
        if (s.input) {
          var f = document.createElement("form");
          f.className = "chat-form";
          var inId = "chat-in-" + s.input.name;
          f.innerHTML = '<label class="sr" for="' + inId + '">' + esc(s.input.placeholder) + '</label>' +
            '<input id="' + inId + '" name="' + esc(s.input.name) + '" type="' + (s.input.type || "text") + '" placeholder="' + esc(s.input.placeholder) + '" required>' +
            '<button type="submit">Enviar</button>';
          f.addEventListener("submit", function (e) {
            e.preventDefault();
            var v = f.querySelector("input").value.trim();
            if (!v) return;
            st[s.input.name] = v;
            bubble(esc(v), "me");
            actions.innerHTML = "";
            if (opts.onAnswer) opts.onAnswer(id, { input: v }, st);
            go(s.input.next);
          });
          actions.appendChild(f);
          setTimeout(function () { var i = f.querySelector("input"); if (i) i.focus({ preventScroll: true }); }, 50);
        }
      });
    }
    function renderCard(c) {
      var href = window.Funil ? window.Funil.withTracking(window.Funil.get(c.button.checkout)) : "#";
      var html = '<div class="chat-card"><b class="cc-title">' + esc(fill(c.title, st)) + '</b>' +
        (c.items ? '<ul>' + c.items.map(function (i) { return "<li>" + esc(fill(i, st)) + "</li>"; }).join("") + "</ul>" : "") +
        (c.price ? '<div class="cc-price">' + esc(fill(c.price, st)) + '</div>' : "") +
        '<a class="cc-btn" href="' + esc(href) + '">' + esc(fill(c.button.label, st)) + '</a>' +
        (c.note ? '<small>' + esc(fill(c.note, st)) + '</small>' : "") + '</div>';
      var b = bubble(html, "bot card");
      b.querySelector(".cc-btn").addEventListener("click", function () { if (window.Funil) window.Funil.track("InitiateCheckout"); });
      if (c.secondary) {
        var s2 = document.createElement("button");
        s2.type = "button"; s2.className = "chat-opt ghost"; s2.textContent = c.secondary.label;
        s2.addEventListener("click", function () { bubble(esc(c.secondary.label), "me"); actions.innerHTML = ""; go(c.secondary.next); });
        actions.appendChild(s2);
      }
    }
    go(opts.inicio || "start");
  }

  window.Funil = window.Funil || {};
  window.Funil.chat = chat;
})();
