/* Utilitários compartilhados: config, UTMs no checkout, Pixel, VSL, liberação da oferta e Netlify Forms. */
(function () {
  var CFG = window.FUNIS || {};

  function get(path) {
    return path.split(".").reduce(function (o, k) { return o == null ? undefined : o[k]; }, CFG);
  }

  // Repassa os parâmetros de rastreio da URL atual para links de checkout e de próxima página.
  var KEEP = /^(utm_|fbclid$|gclid$|src$|sck$|xcod$|ttclid$)/;
  function trackingParams() {
    var out = new URLSearchParams();
    new URLSearchParams(location.search).forEach(function (v, k) { if (KEEP.test(k)) out.set(k, v); });
    return out;
  }
  function withTracking(url, extra) {
    if (!url) return "#";
    try {
      var u = new URL(url, location.href);
      trackingParams().forEach(function (v, k) { if (!u.searchParams.has(k)) u.searchParams.set(k, v); });
      if (extra) Object.keys(extra).forEach(function (k) { u.searchParams.set(k, extra[k]); });
      return u.toString();
    } catch (e) { return url; }
  }

  function applyConfig(root) {
    root = root || document;
    root.querySelectorAll("[data-cfg]").forEach(function (el) {
      var v = get(el.getAttribute("data-cfg"));
      if (v != null) el.textContent = v;
    });
    root.querySelectorAll("[data-checkout]").forEach(function (el) {
      el.setAttribute("href", withTracking(get(el.getAttribute("data-checkout"))));
      el.addEventListener("click", function () { track("InitiateCheckout"); });
    });
    root.querySelectorAll("a[data-next]").forEach(function (el) {
      el.setAttribute("href", withTracking(el.getAttribute("data-next")));
    });
  }

  // Pixel da Meta (só carrega se houver ID).
  function loadPixel() {
    if (!CFG.pixelId) return;
    /* eslint-disable */
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
    /* eslint-enable */
    window.fbq("init", CFG.pixelId);
    window.fbq("track", "PageView");
  }
  // Microsoft Clarity (só carrega se houver ID).
  function loadClarity() {
    if (!CFG.clarityId) return;
    (function (c, l, a, r, i, t, y) {
      c[a] = c[a] || function () { (c[a].q = c[a].q || []).push(arguments); };
      t = l.createElement(r); t.async = 1; t.src = "https://www.clarity.ms/tag/" + i;
      y = l.getElementsByTagName(r)[0]; y.parentNode.insertBefore(t, y);
    })(window, document, "clarity", "script", CFG.clarityId);
  }
  function track(ev, data) { try { if (window.fbq) window.fbq("track", ev, data || {}); } catch (e) {} }

  // Player próprio para .mp4 hospedado junto com o site (estilo VSL: sem barra de avanço, começa mudo com aviso "toque para ouvir").
  function mountMp4(container, src) {
    var es = /^es/i.test(document.documentElement.lang || "");
    container.innerHTML = "";
    container.classList.add("vsl-native");
    var v = document.createElement("video");
    v.src = src; v.muted = true; v.autoplay = true; v.playsInline = true; v.preload = "auto";
    v.setAttribute("playsinline", ""); v.setAttribute("webkit-playsinline", "");
    var ov = document.createElement("button");
    ov.type = "button"; ov.className = "vsl-unmute";
    ov.innerHTML = "<span>" + (es ? "Tu video ya empezó" : "Seu vídeo já começou") + "</span><b>🔊 " + (es ? "Toca para escuchar" : "Toque para ouvir") + "</b>";
    var paused = document.createElement("div");
    paused.className = "vsl-paused"; paused.hidden = true; paused.textContent = "▶";
    var bar = document.createElement("div"); bar.className = "vsl-bar"; bar.innerHTML = "<i></i>";
    container.appendChild(v); container.appendChild(ov); container.appendChild(paused); container.appendChild(bar);
    ov.addEventListener("click", function () {
      v.currentTime = 0; v.muted = false; v.play(); ov.remove(); track("ViewContent", { content_name: "vsl_play" });
    });
    v.addEventListener("click", function () { if (ov.isConnected) return; if (v.paused) v.play(); else v.pause(); });
    v.addEventListener("play", function () { paused.hidden = true; });
    v.addEventListener("pause", function () { if (!ov.isConnected && !v.ended) paused.hidden = false; });
    paused.addEventListener("click", function () { v.play(); });
    // barra de progresso fina, sem permitir avançar
    v.addEventListener("timeupdate", function () {
      if (!v.duration) return;
      bar.firstChild.style.width = (v.currentTime / v.duration * 100).toFixed(2) + "%";
    });
    var pr = v.play(); if (pr && pr.catch) pr.catch(function () {});
    return v;
  }

  // Insere o VSL: .mp4 vira player próprio; HTML (vturb) tem as tags <script> recriadas para executarem.
  function mountVsl(container, html) {
    if (!container) return false;
    if (!html) { container.classList.add("vsl-empty"); return false; }
    if (/\.mp4(\?|$)/i.test(html) && html.indexOf("<") === -1) return mountMp4(container, html);
    container.innerHTML = "";
    var tmp = document.createElement("div");
    tmp.innerHTML = html;
    Array.prototype.slice.call(tmp.childNodes).forEach(function (node) {
      if (node.tagName === "SCRIPT") {
        var s = document.createElement("script");
        Array.prototype.slice.call(node.attributes).forEach(function (a) { s.setAttribute(a.name, a.value); });
        s.text = node.text;
        container.appendChild(s);
      } else {
        container.appendChild(node);
      }
    });
    return true;
  }

  // Libera os blocos [data-reveal] depois de X segundos. Quem já viu a oferta vê direto na volta.
  function reveal(key, seconds, hasVideo) {
    var els = document.querySelectorAll('[data-reveal="' + key + '"]');
    var storeKey = "reveal-" + key;
    function show() {
      els.forEach(function (el) { el.hidden = false; });
      try { localStorage.setItem(storeKey, "1"); } catch (e) {}
    }
    var seen = false;
    try { seen = localStorage.getItem(storeKey) === "1"; } catch (e) {}
    if (!hasVideo || seen || /[?&]reveal=1/.test(location.search)) { show(); return; }
    // Vídeo próprio: libera pelo tempo assistido COM som (quem não ativou o som não conta).
    if (hasVideo && hasVideo.tagName === "VIDEO") {
      var done = false;
      hasVideo.addEventListener("timeupdate", function () {
        if (!done && !hasVideo.muted && hasVideo.currentTime >= (seconds || 60)) { done = true; show(); }
      });
      hasVideo.addEventListener("ended", function () { if (!done) { done = true; show(); } });
      return;
    }
    setTimeout(show, (seconds || 60) * 1000);
  }

  // Envio para o Netlify Forms (o formulário precisa existir no HTML com data-netlify="true").
  function netlifySubmit(formName, data) {
    var body = new URLSearchParams();
    body.set("form-name", formName);
    Object.keys(data).forEach(function (k) { body.set(k, data[k]); });
    return fetch("/", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: body.toString() })
      .catch(function () { /* offline ou rodando local: segue o fluxo mesmo assim */ });
  }

  window.Funil = { cfg: CFG, get: get, withTracking: withTracking, applyConfig: applyConfig, track: track, mountVsl: mountVsl, reveal: reveal, netlifySubmit: netlifySubmit };

  loadPixel();
  loadClarity();
  document.addEventListener("DOMContentLoaded", function () { applyConfig(document); });
})();
